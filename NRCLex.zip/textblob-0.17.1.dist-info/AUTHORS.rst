*******
Authors
*******

Development Lead
================

- Steven Loria <sloria1@gmail.com> `@sloria <https://github.com/sloria>`_

Contributors (chronological)
============================

- Pete Keen `@peterkeen <https://github.com/peterkeen>`_
- Matthew Honnibal `@syllog1sm <https://github.com/syllog1sm>`_
- Roman Yankovsky `@RomanYankovsky <https://github.com/RomanYankovsky>`_
- David Karesh `@davidnk <https://github.com/davidnk>`_
- Evan Dempsey `@evandempsey <https://github.com/evandempsey>`_
- Wesley Childs `@mrchilds <https://github.com/mrchilds>`_
- Jeff Schnurr `@jschnurr <https://github.com/jschnurr>`_
- Adel Qalieh `@adelq <https://github.com/adelq>`_
- Lage Ragnarsson `@lragnarsson <https://github.com/lragnarsson>`_
- Jonathon Coe `@jonmcoe <https://github.com/jonmcoe>`_
- Adrián López Calvo `@AdrianLC <https://github.com/AdrianLC>`_
- Nitish Kulshrestha `@nitkul <https://github.com/nitkul>`_
- Jhon Eslava `@EpicJhon <https://github.com/EpicJhon>`_
- `@jcalbert <https://github.com/jcalbert>`_
- Tyler James Harden `@tylerjharden <https://github.com/tylerjharden>`_
- `@pavelmalai <https://github.com/pavelmalai>`_
- Jeff Kolb `@jeffakolb <https://github.com/jeffakolb>`_
- Daniel Ong `@danong <https://github.com/danong>`_
- Jamie Moschella `@jammmo <https://github.com/jammmo>`_
- Roman Korolev `@roman-y-korolev <https://github.com/roman-y-korolev>`_
- Ram Rachum `@cool-RR <https://github.com/cool-RR>`_
- Romain Casati `@casatir <https://github.com/casatir>`_
- Evgeny Kemerov `@sudoguy <https://github.com/sudoguy>`_

import os

__version__ = '3.0.0'
__license__ = 'MIT'
__author__ = 'metalcorebear'

name = "NRCLex"

PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))